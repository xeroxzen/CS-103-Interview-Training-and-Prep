def nth_int_without_nine(n):
	"""
	Given a positive integer n, you need to return the n-th integer after removing. 
	Note that 1 will be the first integer.

	Check q3.md for a detailed description.

	>>> print(nth_int_without_nine(9))
	10
	"""
	pass
